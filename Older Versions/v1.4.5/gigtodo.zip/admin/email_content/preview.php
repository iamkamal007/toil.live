<?php 

   include("includes/db.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Preview</title>
</head>
<body>
   


</body>
</html>