<?php 

   include("parts/header.php"); 
   include($data['template'].".php"); 
   include("parts/footer.php"); 

?>