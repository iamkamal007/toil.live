UPDATE `app_info` SET `version` = '1.5.0', `r_date` = '2 May 2020';

ALTER TABLE `admins` ADD `isS3` INT(10) NOT NULL AFTER `admin_about`;
ALTER TABLE `buyer_requests` ADD `isS3` INT(10) NOT NULL AFTER `request_status`;
ALTER TABLE `home_cards` ADD `isS3` INT(10) NOT NULL AFTER `card_image`;
ALTER TABLE `home_section_slider` ADD `isS3` INT(10) NOT NULL AFTER `slide_image`;
ALTER TABLE `inbox_messages` ADD `isS3` INT(10) NOT NULL AFTER `message_status`;
ALTER TABLE `languages` ADD `isS3` INT(10) NOT NULL AFTER `direction`;
ALTER TABLE `section_boxes` ADD `isS3` INT(10) NOT NULL AFTER `box_image`;
ALTER TABLE `slider` ADD `isS3` INT(10) NOT NULL AFTER `slide_url`;
ALTER TABLE `support_tickets` ADD `isS3` INT(10) NOT NULL AFTER `status`;


ALTER TABLE `general_settings` ADD `site_favicon_s3` INT(10) NOT NULL AFTER `site_logo`, ADD `site_logo_image_s3` INT(10) NOT NULL AFTER `site_favicon_s3`, ADD `site_logo_s3` INT(10) NOT NULL AFTER `site_logo_image_s3`, ADD `site_watermark` VARCHAR(255) NOT NULL AFTER `site_logo_s3`, ADD `google_analytics` TEXT NOT NULL AFTER `site_watermark`, ADD `site_color` TEXT NOT NULL AFTER `google_analytics`, ADD `site_hover_color` VARCHAR(255) NOT NULL AFTER `site_color`, ADD `site_border_color` VARCHAR(255) NOT NULL AFTER `site_hover_color`;

ALTER TABLE `general_settings` ADD `revisions_list` TEXT NOT NULL AFTER `proposal_email`, ADD `enable_unlimited_revisions` INT(10) NOT NULL AFTER `revisions_list`;

ALTER TABLE `general_settings` ADD `edited_proposals` INT(10) NOT NULL AFTER `approve_proposals`, ADD `disable_local_video` INT(10) NOT NULL AFTER `edited_proposals`;

ALTER TABLE `general_settings` ADD `currency_position` VARCHAR(255) NOT NULL AFTER `site_currency`, ADD `currency_format` TEXT NOT NULL AFTER `currency_position`;

ALTER TABLE `cart` ADD `revisions` VARCHAR(255) NOT NULL AFTER `proposal_price`;

ALTER TABLE `cart` ADD `delivery_id` INT(10) NOT NULL AFTER `proposal_qty`;

ALTER TABLE `categories` ADD `enable_watermark` INT(10) NOT NULL AFTER `cat_featured`, ADD `isS3` INT(10) NOT NULL AFTER `enable_watermark`;

ALTER TABLE `knowledge_bank` ADD `right_image_s3` INT(10) NOT NULL AFTER `article_status`, ADD `top_image_s3` INT(10) NOT NULL AFTER `right_image_s3`, ADD `bottom_image_s3` INT(10) NOT NULL AFTER `top_image_s3`;

ALTER TABLE `orders` ADD `order_revisions` VARCHAR(255) NOT NULL AFTER `order_date`, ADD `order_revisions_used` INT(10) NOT NULL AFTER `order_revisions`;

ALTER TABLE `order_conversations` ADD `watermark` INT(10) NOT NULL AFTER `status`, ADD `watermark_file` VARCHAR(255) NOT NULL AFTER `watermark`, ADD `isS3` INT(10) NOT NULL AFTER `watermark_file`;

ALTER TABLE `payment_settings` ADD `enable_mercadopago` INT(10) NOT NULL AFTER `paystack_secret_key`, ADD `mercadopago_access_token` TEXT NOT NULL AFTER `enable_mercadopago`, ADD `mercadopago_currency` VARCHAR(255) NOT NULL AFTER `mercadopago_access_token`, ADD `mercadopago_sandbox` INT(10) NOT NULL AFTER `mercadopago_currency`;

ALTER TABLE `payment_settings` ADD `min_proposal_price` INT(10) NOT NULL AFTER `id`;

ALTER TABLE `payment_settings` ADD `dusupay_method` VARCHAR(255) NOT NULL AFTER `dusupay_secret_key`, ADD `dusupay_provider_id` VARCHAR(255) NOT NULL AFTER `dusupay_method`, ADD `dusupay_payout_method` VARCHAR(255) NOT NULL AFTER `dusupay_provider_id`, ADD `dusupay_payout_provider_id` VARCHAR(255) NOT NULL AFTER `dusupay_payout_method`;

ALTER TABLE `proposals` ADD `proposal_img1_s3` INT(10) NOT NULL AFTER `proposal_video`, ADD `proposal_img2_s3` INT(10) NOT NULL AFTER `proposal_img1_s3`, ADD `proposal_img3_s3` INT(10) NOT NULL AFTER `proposal_img2_s3`, ADD `proposal_img4_s3` INT(10) NOT NULL AFTER `proposal_img3_s3`, ADD `proposal_video_s3` INT(10) NOT NULL AFTER `proposal_img4_s3`;

ALTER TABLE `proposals` ADD `proposal_revisions` VARCHAR(255) NOT NULL AFTER `delivery_id`;

ALTER TABLE `revenues` ADD `reason` VARCHAR(255) NOT NULL AFTER `order_id`;

ALTER TABLE `sales` CHANGE `amount` `amount` VARCHAR(255) NOT NULL, CHANGE `profit` `profit` VARCHAR(255) NOT NULL, CHANGE `processing_fee` `processing_fee` VARCHAR(255) NOT NULL;

ALTER TABLE `sellers` ADD `seller_image_s3` INT(10) NOT NULL AFTER `seller_cover_image`, ADD `seller_cover_image_s3` INT(10) NOT NULL AFTER `seller_image_s3`, ADD `seller_city` VARCHAR(255) NOT NULL AFTER `seller_country`, ADD `enable_notifications` INT(10) NOT NULL DEFAULT '1' AFTER `enable_sound`;

ALTER TABLE `smtp_settings` ADD `library` VARCHAR(255) NOT NULL AFTER `id`;



UPDATE `cart` SET revisions='0';

UPDATE `sellers` SET enable_notifications='1';

UPDATE `revenues` SET reason='order';

UPDATE `payment_settings` SET min_proposal_price='5';

UPDATE `proposals` SET proposal_revisions='0';

UPDATE `general_settings` SET site_watermark='watermark.jpg',site_color='#2ca35b',site_hover_color='#2ca35b',site_border_color='#2ca35b',currency_position='left',currency_format='us';

UPDATE `smtp_settings` SET `library` = 'php_mailer';

INSERT INTO `footer_links` (`language_id`, `icon_class`, `link_title`, `link_url`, `link_section`) VALUES
(1, 'fa-rss', 'Blog', '/blog', 'about'),
(1, 'fa-commenting-o', 'Feedback', '/feedback', 'about');

TRUNCATE `cart`;


--
-- Create Tables
--

CREATE TABLE `admin_rights` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `admin_id` varchar(10) NOT NULL,
 `settings` int(11) NOT NULL,
 `plugins` int(10) NOT NULL,
 `pages` int(11) NOT NULL,
 `blog` int(10) NOT NULL,
 `feedback` int(10) NOT NULL,
 `video_schedules` int(10) NOT NULL,
 `proposals` int(11) NOT NULL,
 `accounting` int(10) NOT NULL,
 `payouts` int(10) NOT NULL,
 `reports` int(11) NOT NULL,
 `inbox` int(11) NOT NULL,
 `reviews` int(11) NOT NULL,
 `buyer_requests` int(11) NOT NULL,
 `restricted_words` int(11) NOT NULL,
 `notifications` int(11) NOT NULL,
 `cats` int(11) NOT NULL,
 `delivery_times` int(11) NOT NULL,
 `seller_languages` int(11) NOT NULL,
 `seller_skills` int(11) NOT NULL,
 `seller_levels` int(10) NOT NULL,
 `customer_support` int(11) NOT NULL,
 `coupons` int(11) NOT NULL,
 `slides` int(11) NOT NULL,
 `terms` int(11) NOT NULL,
 `sellers` int(11) NOT NULL,
 `orders` int(11) NOT NULL,
 `referrals` int(11) NOT NULL,
 `files` int(11) NOT NULL,
 `knowledge_bank` int(10) NOT NULL,
 `currencies` int(10) NOT NULL,
 `languages` int(11) NOT NULL,
 `admins` int(11) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


CREATE TABLE `announcement_bar` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `enable_bar` varchar(255) NOT NULL,
 `bg_color` varchar(255) NOT NULL,
 `text_color` varchar(255) NOT NULL,
 `bar_text` varchar(255) NOT NULL,
 `last_updated` varchar(255) NOT NULL,
 `language_id` int(10) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


CREATE TABLE `api_settings` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `enable_s3` int(10) NOT NULL,
 `s3_access_key` varchar(255) NOT NULL,
 `s3_access_sceret` varchar(255) NOT NULL,
 `s3_bucket` varchar(255) NOT NULL,
 `s3_region` varchar(255) NOT NULL,
 `s3_domain` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


CREATE TABLE `currency_converter_settings` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `enable` int(10) NOT NULL,
 `api_key` varchar(255) NOT NULL,
 `main_currency` varchar(255) NOT NULL,
 `server` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


CREATE TABLE `instant_deliveries` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `proposal_id` int(10) NOT NULL,
 `enable` int(10) NOT NULL,
 `message` text NOT NULL,
 `file` varchar(255) NOT NULL,
 `isS3` int(10) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=latin1;

CREATE TABLE `order_tips` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `order_id` int(10) NOT NULL,
 `amount` int(10) NOT NULL,
 `message` varchar(255) NOT NULL,
 `date` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


CREATE TABLE `comments` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `idea_id` int(100) NOT NULL,
 `seller_id` int(100) NOT NULL,
 `comment` text NOT NULL,
 `date` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

CREATE TABLE `ideas` (
 `id` int(100) NOT NULL AUTO_INCREMENT,
 `seller_id` int(100) NOT NULL,
 `votes` int(100) NOT NULL,
 `title` text NOT NULL,
 `content` text NOT NULL,
 `date` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

CREATE TABLE `pages` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `title` text NOT NULL,
 `url` text NOT NULL,
 `content` text NOT NULL,
 `language_id` int(10) NOT NULL,
 `date` text NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;


CREATE TABLE `posts` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `title` varchar(50) NOT NULL,
 `cat_id` varchar(50) NOT NULL,
 `author` varchar(50) NOT NULL,
 `image` varchar(500) NOT NULL,
 `content` text NOT NULL,
 `date_time` text NOT NULL,
 `isS3` int(10) NOT NULL,
 `language_id` int(10) NOT NULL,
 `status` int(10) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

CREATE TABLE `post_categories` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `cat_name` varchar(50) NOT NULL,
 `cat_image` varchar(255) NOT NULL,
 `cat_creator` varchar(50) NOT NULL,
 `date_time` varchar(255) NOT NULL,
 `isS3` int(10) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

CREATE TABLE `post_comments` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `post_id` int(100) NOT NULL,
 `seller_id` int(100) NOT NULL,
 `comment` text NOT NULL,
 `date` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

CREATE TABLE `site_currencies` (
 `id` int(10) NOT NULL AUTO_INCREMENT,
 `currency_id` int(10) NOT NULL,
 `code` varchar(255) NOT NULL,
 `position` varchar(255) NOT NULL,
 `format` varchar(255) NOT NULL,
 `rate` varchar(255) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;


INSERT INTO `admin_rights` (`admin_id`) SELECT `admin_id` FROM `admins`;

UPDATE admin_rights set `settings` = '1',`plugins` = '1',`pages` = '1',`blog` = '1',`feedback` = '1',`video_schedules` = '1',`proposals` = '1',`accounting` = '1',`payouts` = '1',`reports` = '1',`inbox` = '1',`reviews` = '1',`buyer_requests` = '1',`restricted_words` = '1',`notifications` = '1',`cats` = '1',`delivery_times` = '1',`seller_languages` = '1',`seller_skills` = '1',`seller_levels` = '1',`customer_support` = '1',`coupons` = '1',`slides` = '1',`terms` = '1',`sellers` = '1',`orders` = '1',`referrals` = '1',`files` = '1',`knowledge_bank` = '1',`currencies` = '1',`languages` = '1',`admins` = '1';

INSERT INTO `announcement_bar` (`language_id`) SELECT `id` FROM `languages`;

UPDATE announcement_bar set `enable_bar` = '0',`bg_color` = '#2ca35b',`text_color` = '#ffffff';

INSERT INTO `api_settings` (`id`, `enable_s3`, `s3_access_key`, `s3_access_sceret`, `s3_bucket`, `s3_region`, `s3_domain`) VALUES (1, 0, '', '', '', '', '');

INSERT INTO `instant_deliveries` (`proposal_id`) SELECT `proposal_id` FROM `proposals`;

INSERT INTO `currency_converter_settings` (`id`, `enable`, `api_key`, `main_currency`, `server`) VALUES (1, 0, '', '', '');